#ifndef __comm_PORT_H__
#define __comm_PORT_H__

t_connection * comm_port_accept(t_tcp_port * port);

#endif
