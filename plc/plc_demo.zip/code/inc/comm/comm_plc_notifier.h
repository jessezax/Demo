#ifndef __comm_POLICY_H__
#define __comm_POLICY_H__

bool comm_plc_notify(e_comm_plc_type type,u32 version,e_comm_data_type data_type,void * data,int data_size);

#endif
