#ifndef __comm_TIMER_TASK_H__
#define __comm_TIMER_TASK_H__

void comm_timer_task_add(t_connection * conn);

void comm_timer_task_del(t_connection * conn);

#endif
